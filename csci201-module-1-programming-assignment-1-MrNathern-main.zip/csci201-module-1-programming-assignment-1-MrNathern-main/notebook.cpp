#include "notebook.h"

Class functions are implemented here